﻿<?php
if(!defined("AP")) exit();

$config['database_host']="localhost";
$config['database_name']="cran";		
$config['database_user']="cran1";		
$config['database_passw']="cran";	
?>