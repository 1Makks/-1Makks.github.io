﻿<?php

if(!defined("AP")) exit("Доступ к файлу напрямую запрещен!");

// Вывод title
echo("<title>Оплата произведена успешно! : ".$params_array[0]."</title>");

echo("

<br><center><h3><img src='/template/apimages/ok.png'> Оплата произведена успешно!</h3></center>

<br><br>");
?>