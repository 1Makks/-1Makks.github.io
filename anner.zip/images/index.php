<?php
if(!defined("AP")) header("location: /index.php");

?>