﻿<?php

if(!defined("AP")) exit("Доступ к файлу напрямую запрещен!");

// Вывод title
echo("<title>Вы успешно зарегистрировались! : ".$params_array[0]."</title>");

echo("

<br><center><h3><img src='/template/apimages/ok.png'> Вы успешно зарегистрировались!</h3></center>

<br><br>");
?>